package com.example.test4

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun Restaurant(navController: NavController) {
    Column (
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFDAB9))
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        Text(
            text = "List of Cafes",
            style = MaterialTheme.typography.headlineLarge.copy(color=Color.DarkGray)
        )
        Button(
            onClick = {
                navController.navigate("Food")
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ){
            Text(text="The Cakefectionary")
        }
        Button(
            onClick = {
                navController.navigate("Donut")
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ){
            Text(text="Doughnut Disturb")
        }
        Button(
            onClick = {
                navController.navigate("Icecream")
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ){
            Text(text="I-SCREAM")
        }
    }
}