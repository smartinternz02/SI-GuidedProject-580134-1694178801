package com.example.test4

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

@Composable
fun Food(navController: NavController){
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFDAB9))
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFAEC6CF))
        ){
            Image(
                painter = painterResource(id = R.drawable.blue )
            )
            Text(text = "Blueberry Chesirecake")
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFAEC6CF))
        ){
            Image(
                painter = painterResource(id = R.drawable.choc )
            )
            Text(text = "The Darkest Fantasy")
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFAEC6CF))
        ){
            Image(
                painter = painterResource(id = R.drawable.vanil )
            )
            Text(text = "Confetti Combustion")
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFAEC6CF))
        ){
            Image(
                painter = painterResource(id = R.drawable.mint )
            )
            Text(text = "Don't Leaf Me")
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFAEC6CF))
        ){
            Image(
                painter = painterResource(id = R.drawable.straw )
            )
            Text(text = "Strawberry Shortbake")
        }
    }
}
