package com.example.test4

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun Donut(navController : NavController){
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFDAB9))
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFAEC6CF))
        ){
            Image(
                painter = painterResource(id = R.drawable.d1 ),
                contentDescription="null"
            )
            Text(text = "The Snooze Donut")
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFAEC6CF))
        ){
            Image(
                painter = painterResource(id = R.drawable.d2 ),
                contentDescription = null
            )
            Text(text = "Binge Donut")
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFAEC6CF))
        ){
            Image(
                painter = painterResource(id = R.drawable.d3 ),
                contentDescription = null
            )
            Text(text = "Donut 777")
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFAEC6CF))
        ){
            Image(
                painter = painterResource(id = R.drawable.d4),
                contentDescription = null
            )
            Text(text = "Donut Leave!")
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFAEC6CF))
        ){
            Image(
                painter = painterResource(id = R.drawable.d5 ),
                contentDescription = null
            )
            Text(text = "The Donut")
        }
    }
}
